import '../css/style.scss';
import './mailer';
import "animate.css/source/animate.css";
import { WOW } from "wowjs";


const wow = new WOW();
wow.init();
//import mailer from "./mailer";


//var mmailer = new mailer();


