import '../css/style.scss';
import './mailer';

//import mailer from "./mailer";


//var mmailer = new mailer();


